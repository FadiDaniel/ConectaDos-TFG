import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:conectados/common/firebase/auth.dart';
import 'package:conectados/common/firebase/firestore.dart';
import 'package:conectados/model/company.dart';
import 'package:conectados/model/student.dart';
import 'package:conectados/model/tutor.dart';
import 'package:dartz/dartz.dart';

class SG {
  static Auth auth = Auth();
  static FirestoreManager firestore = FirestoreManager();
  static Student? student;
  static Company? company;
  static Tutor? tutor;

  static Future<void> initializeUser() async {
    Either either = await SG.firestore.retrieveStudent();
    either.fold((ifLeft) {}, (ifRight) {
      if (ifRight is Student) {
        student = ifRight;
        return;
      }
    });
    either = await SG.firestore.retrieveTutor();
    either.fold((ifLeft) {}, (ifRight) {
      tutor = ifRight;
      return;
    });
    // either = await SG.firestore.retrieveCompany();
    // either.fold((ifLeft) {}, (ifRight) {
    //   company = ifRight;
    //   return;
    // });
  }
}
