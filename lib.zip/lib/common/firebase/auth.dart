import 'package:conectados/common/firebase/firestore.dart';
import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Auth {
  final FirebaseAuth firebaseAuth = FirebaseAuth.instance;

  User? get currentUser => firebaseAuth.currentUser;

  Stream<User?> get authStateChanges => firebaseAuth.authStateChanges();

  Future<bool> logIn({required String email, required String password}) async {
    try {
      await firebaseAuth.signInWithEmailAndPassword(
          email: email, password: password);
      await SG.initializeUser();
      return true;
    } on FirebaseAuthException {
      return false;
    }
  }

  Future<void> signUp({required String email, required String password}) async {
    await firebaseAuth.createUserWithEmailAndPassword(
        email: email, password: password);
    sendEmail();
  }

  Future<void> signOut() async {
    await firebaseAuth.signOut();
  }

  Future<void> sendEmail() async {
    await currentUser!.sendEmailVerification();
  }
}
