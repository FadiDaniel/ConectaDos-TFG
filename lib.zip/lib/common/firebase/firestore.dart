import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/model/company.dart';
import 'package:conectados/model/position.dart';
import 'package:conectados/model/student.dart';
import 'package:conectados/model/tutor.dart';
import 'package:dartz/dartz.dart';
import 'package:firebase_core/firebase_core.dart';

class FirestoreManager {
  //sign up, codes
  Future<bool> isTutorCodeOK(String code) async {
    var codeDB = await FirebaseFirestore.instance
        .collection("codes")
        .doc("tutorRegistration")
        .get();
    return codeDB["code"] == code;
  }

  Future<bool> isStudentCodeOK(String code) async {
    var codeDB =
        await FirebaseFirestore.instance.collection("codes").doc(code).get();
    return codeDB.exists;
  }

  Future<bool> isCompanySignUpDone() async {
    var company = await FirebaseFirestore.instance
        .collection("companies")
        .doc(SG.auth.currentUser!.uid)
        .get();
    if (company.exists) {
      return true;
    }
    return false;
  }

  Future<bool> isStudentSignUpDone() async {
    var student = await FirebaseFirestore.instance
        .collection("students")
        .doc(SG.auth.currentUser!.uid)
        .get();
    if (student.exists) {
      return true;
    }
    return false;
  }

  Future<bool> generateTutorCode(
      String code, String city, String highSchool, String fp) async {
    try {
      await FirebaseFirestore.instance.collection("codes").doc(code).set(
          {"city": city, "fp": fp, "highSchool": highSchool},
          SetOptions(merge: true));
      return true;
    } on FirebaseException {
      return false;
    }
  }

  Future<bool> isTutorCodeTaken(String code) async {
    try {
      var document =
          await FirebaseFirestore.instance.collection("codes").doc(code).get();
      return (document.exists);
    } on FirebaseException {
      return false;
    }
  }

  Future<bool> writeStudentInTutorCode(String code, String uid) async {
    try {
      await FirebaseFirestore.instance.collection("codes").doc(code).update({
        "students": FieldValue.arrayUnion([uid]),
      });
      return true;
    } on Exception {
      return false;
    }
  }

  //companies
  Future<bool> writeCompany(Company company) async {
    try {
      await FirebaseFirestore.instance
          .collection("companies")
          .doc(SG.auth.currentUser!.uid)
          .set({
        "companyName": company.companyName,
        "cif": company.cif,
        "represName": company.represName,
        "repreSurnames": company.repreSurnames,
        "dni": company.dni,
        "adress": company.adress,
        "municipality": company.municipality,
        "city": company.city,
        "cp": company.cp,
        "phone": company.phone,
        "fax": company.fax,
        "email": company.email,
        "positions": [],
      }, SetOptions(merge: true));
      return true;
    } on Exception {
      return false;
    }
  }

  Future<Either> retrieveCompany() async {
    try {
      var document = await FirebaseFirestore.instance
          .collection("companies")
          .doc(SG.auth.currentUser!.uid)
          .get();

      if (document.exists) {
        var company = Company.fromDB(
            id: document["id"],
            companyName: document["companyName"],
            cif: document["cif"],
            represName: document["represName"],
            repreSurnames: document["repreSurnames"],
            dni: document["dni"],
            adress: document["adress"],
            municipality: document["municipality"],
            city: document["city"],
            cp: document["cp"],
            phone: document["phone"],
            fax: document["fax"],
            email: document["email"],
            sector: document["sector"],
            description: document["description"],
            imageRoute: document["imageRoute"],
            positions: document["positions"]);
        return Right(company);
      } else {
        return Right(null);
      }
    } on Exception {
      return Left(null);
    }
  }

  //student

  Future<Either> retrieveStudent() async {
    try {
      var document = await FirebaseFirestore.instance
          .collection("students")
          .doc(SG.auth.currentUser!.uid)
          .get();
      if (document.exists) {
        var student = Student.all(
            id: document.id,
            name: document["studentName"],
            surnames: document["studentSurnames"],
            fp: document["fp"],
            city: document["city"],
            highSchool: document["highSchool"],
            presentation: document["presentation"],
            interests: document["interests"],
            experience: document["experience"],
            skills: document["skills"],
            likes: document["likes"],
            dislikes: document["dislikes"]);

        return Right(student);
      } else {
        return Right(null);
      }
    } on Exception {
      return Left(null);
    }
  }

  Future<bool> writeStudent(Student student) async {
    try {
      await FirebaseFirestore.instance
          .collection("students")
          .doc(SG.auth.currentUser!.uid)
          .set({
        "studentName": student.name,
        "studentSurnames": student.surnames,
        "FP": student.fp,
        "city": student.city,
        "highSchool": student.highSchool,
        "presentation": "",
        "skills": [],
        "interests": [],
        "experiences": [],
      });
      return true;
    } on Exception {
      return false;
    }
  }

  Future<Map<String, String>> fetchCityFPfromCode(String code) async {
    var tutorCode =
        await FirebaseFirestore.instance.collection("codes").doc(code).get();
    Map<String, String> dict = {};
    dict.addAll({
      "city": tutorCode["city"],
      "fp": tutorCode["fp"],
      "highSchool": tutorCode["highSchool"]
    });
    return dict;
  }

  //tutor

  Future<Either> retrieveTutor() async {
    try {
      var document = await FirebaseFirestore.instance
          .collection("tutors")
          .doc(SG.auth.currentUser!.uid)
          .get();

      if (document.exists) {
        var tutor = Tutor.fromDB(
          id: document.id,
          name: document["name"],
          surnames: document["surnames"],
          fp: document["fp"],
          city: document["city"],
          highSchool: document["highSchool"],
          code: document["code"],
          students: document["student"],
          companies: document["companies"],
          positions: document["positions"],
        );
        return Right(tutor);
      } else {
        return Right(null);
      }
    } on Exception {
      return Left(null);
    }
  }

  Future<bool> writeTutor(Tutor tutor) async {
    try {
      await FirebaseFirestore.instance
          .collection("tutors")
          .doc(SG.auth.currentUser!.uid)
          .set({
        "name": tutor.name,
        "surnames": tutor.surnames,
        "fp": tutor.fp,
        "city": tutor.city,
        "highSchool": tutor.highSchool,
        "code": tutor.code,
        "registrationTime": FieldValue.serverTimestamp()
      });
      await FirebaseFirestore.instance.collection("codes").doc(tutor.code).set({
        "fp": tutor.fp,
        "city": tutor.city,
        "highSchool": tutor.highSchool,
      });
      return true;
    } on Exception {
      return false;
    }
  }

  Future<List<Student>> retrieveStudents(String code) async {
    List<Student> students = [];
    try {
      final studentsCollection = await FirebaseFirestore.instance
          .collection("students")
          .where("code", isEqualTo: code)
          .get();

      students = studentsCollection.docs
          .map((document) => Student.all(
              id: document.id,
              name: document["name"],
              surnames: document["surnames"],
              fp: document["fp"],
              city: document["city"],
              highSchool: document["highSchool"],
              presentation: document["presentation"],
              interests: document["interests"],
              experience: document["experiences"],
              skills: document["skills"],
              likes: document["likes"],
              dislikes: document["dislikes"]))
          .toList();
      return students;
    } on Exception {
      return [];
    }
  }

  //positions

  Future<Either> retrievePositions(String fp, String city) async {
    List<Position> positions = [];
    try {
      final positionCollection = await FirebaseFirestore.instance
          .collection("positions")
          .where("city", isEqualTo: city)
          .where("fp", isEqualTo: fp)
          .get();
      positions = positionCollection.docs
          .map((doc) => Position(
                id: doc["id"],
                name: doc["name"],
                fp: doc["fp"],
                city: "Madrid",
                description: doc["description"],
                requirements: doc["requirements"],
                vacants: doc["vacants"],
              ))
          .toList();
      return Right(positions);
    } on Exception {
      return Left(Ss.errorPositions);
    }
  }
}
