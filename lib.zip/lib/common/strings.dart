class Ss {
  //títulos
  static String login = "Iniciar sesión";
  static String recoverPassword = "Recuperar contraseña";
  static String studentSignUp = "Cuéntanos sobre ti";
  static String conectados = "ConectaDos";

  //log in
  static String email = "Correo electrónico";
  static String password = "Contraseña";
  static String enter = "Entrar";
  static String makeAccount = "Crear cuenta";
  static String forgotten = "¿Has olvidado la contraseña?";
  static String dontHave = "¿No tienes cuenta?";
  static String emailNotVerified = "Correo electrónico no confirmado";
  static String emailNotVerifiedContent =
      "Debe confirmar su correo electrónico para poder iniciar sesión. ";
  static String sendEmailAgain =
      "Pulse para volver a mandar un email de confirmación.";

  //sign up
  static String surname = "Apellidos";
  static String name = "Nombre";
  static String student = "Estudiante";
  static String tutor = "Tutor";
  static String company = "Empresa";
  static String userType = "Tipo de usuario";
  static String accept = "Acepto los términos y condiciones";
  static String continuE = "Continuar";
  static String cancel = "Cancelar";
  static String selectUser = "Seleccionar tipo de usuario";
  static String register = "Registrarse";
  static String tutorCodeIntroduce = "Introduzca el código de tutor";
  static String studentCodeIntroduce = "Introduzca el código de estudiante";
  static String tutorCode = "Código de tutor";
  static String studentCode = "Código de estudiante";
  //student Sign up
  static String professionalExp = "Experiencia profesional";
  static String jobTitle = "Puesto ocupado, tiempo";
  static String jobFunctions = "Funciones desempeñadas";
  static String skills = "Habilidades";
  static String skill = "Habilidad";
  static String interest = "Interés";
  static String interests = "Intereses";
  static String presentation = "Carta de presentación";
  static String charactersMax = " (máximo 500 caracteres)";
  static String finalize = "Finalizar";
  static String remove = "Eliminar";
  static String addExp = "Añadir experiencia";
  static String addSkill = "Añadir habilidad";
  static String addInterest = "Añadir interés";
  static String removeJob = "Eliminar trabajo";
  static String removeSkill = "Eliminar habilidad";
  static String removeInterest = "Eliminar interés";
  static String removeJobDesc = "Pulsa en la papelera para eliminar un trabajo";
  static String removeSkillDesc =
      "Pulsa en la papelera para eliminar una habilidad";
  static String removeInterestDesc =
      "Pulsa en la papelera para eliminar un interés";
  static String city = "Ciudad";
  static String fp = "Ciclo de FP";
  static String highSchool = "Instituto";
  static String selectHighSchool = "Seleccione su instituto";
  static String selectCity = "Seleccione su ciudad";
  static String selectFP = "Seleccione su FP";
  static String type = "Teclee para buscar";
  static String noResults =
      "No se han encontrado resultados con el texto especificado";

  //student modifyCV
  static String modifyCV = "Modificar CV";

  //tutor signup
  static String tutorFP = "Seleccione el FP que tutoriza";
  static String mandatoryFields = "Campos obligatorios";

  //tutor
  static String chooseUser = "¿Qué quieres ver?";
  static String noStudents = "Aún no tienes estudiantes registrados";
  static String registerCode =
      "Genere su código de registro para sus estudiantes";
  static String seePositions = "Ver puestos";

  //signout
  static String signOut = "Cerrar sesión";
  static String messageSignOut = "¿Está seguro de que desea cerrar sesión?";
  static String confirm = "Confirmar";

  //position editor
  static String titlePosition = "Editor de posiciones";

  //company sign up
  static String companyName = "Nombre";
  static String companyNameTitle = "Denominación de la empresa";
  static String cif = "CIF";
  static String dni = "Número de identificación legal";
  static String legalRepresentative = "Representante legal";
  static String adress = "Dirección";
  static String completeAdress = "Dirección completa";
  static String municipality = "Municipio";
  static String cp = "Código postal";
  static String contactInformation = "Datos de contacto";
  static String phone = "Teléfono";
  static String fax = "Fax";

  //company homepage
  static String students = "Estudiantes";

  //positionEditor screen
  static String position = "Posición";
  static String aimFPs = "FPs que optan";
  static String requeriments = "Requerimientos";
  static String valuable = "Aspectos a valorar";
  static String addRequirement = "Añadir requerimiento";
  static String removeRequirement = "Eliminar requerimiento";
  static String removeRequirementDesc =
      "Pulse para papelera para eliminar un requerimiento";
  static String returnHomePage = "Regresar a la página principal";
  static String positionCreated = "Posición creada con éxito";

  //positionEditor
  static String positionTitle = "Nombre del puesto";
  static String positionDescription =
      "Descripción del puesto y tareas a realizar";
  static String makePosition = "Crear posición";
  static String pressToShow = "Pulse para seleccionar una";
  static String requirements = "Requerimientos";
  static String requirement = "Requerimiento";
  static String fillRequirement =
      "Rellene el último requerimiento para añadir otro";

  //messages
  static String confirmPass = "Confirmar contraseña";
  static String emailSent = "Se ha enviado un email.";
  static String checkEmail = "Consulte su bandeja de entrada.";
  static String returnLogin = "Regresar a Log in";

  //errors
  static String errorEmail = "Correo introducido no válido";
  static String fill = "Por favor rellene todos los campos obligatorios";
  static String lengthPass =
      "La contraseña debe contener al menos 6 caracteres";
  static String differentPass =
      "Las dos contraseñas introducidas son distintas";
  static String selectType = "Debe seleccionar un tipo de perfil";
  static String mustAccept = "Debe aceptar términos y condiciones";
  static String fillSkill =
      "¡Debes rellenar la última habilidad para poder añadir otra!";
  static String fillInterest =
      "¡Debes rellenar el último interés para poder añadir otro!";
  static String fillExp =
      "Debes rellenar la última experiencia profesional para añadir otra";
  static String fillLast = "Rellena el último campo o bórralo para ordenar";
  static String fpAlreadySet = "La FP seleccionada ya estaba añadida";
  static String pleaseWait = "Por favor, espere...";
  static String errorWriteDB = "Ha ocurrido un error al guardar los datos";
  static String errorPositions = "Ha ocurrido un error leyendo las posiciones";
  static String errorCode = "El código introducido no es correcto";
  static String takenCode =
      "El código introducido ya está siendo utilizado. Escoja otro.";
  static String loginError =
      "Ha habido un error al iniciar sesión. Inténtelo de nuevo más tarde.";

  //firebase
  static String emailTaken =
      "El email introducido ya está asociado a una cuenta";
  static String emailTakenFB = "email-already-in-use";
  static String succesful = "Usuario creado con éxito";
  static String emailSentConfirm =
      "Se ha enviado un email de confirmación, consulte su bandeja de entrada";
  static String invalidCredentialsFB = "invalid-credential";
  static String invalidCredentials =
      "Correo o contraseña introducidos incorrectos";
  static String verifyEmail =
      "Por favor, verifique su email para iniciar sesión";

  //listas
  static List<String> fps = [
    "Desarrollo de Aplicaciones Multiplataforma (DAM)",
    "Desarrollo de Aplicaciones Web (DAW)",
    "Administración de Sistemas Informáticos en Red (ASIR)",
    "Operaciones de Laboratorio",
    "Laboratorio de Análisis y Control de Calidad",
    "Química y Salud Ambiental",
  ];

  static List<String> highSchools = [
    "IES Lope de Vega",
    "Carmencitas",
    "Loles León",
    "Dolores Hurtado",
    "Mendoza IES JEJE"
  ];

  static List<String> cities = [
    "Madrid",
    "Rivas",
    "Ciempozuelos",
    "Tres Cantos",
    "Arganda del Rey"
  ];

  static List<String> users = ["Estudiante", "Tutor", "Empresa"];

  static List<String> idiomas = ["ES", "EN"];
  static List<String> idiomas2 = ["Español", "English"];
}
