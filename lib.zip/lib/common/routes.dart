class Routes {
  static String logo = "assets/images/logo.png";
  static String banner = "assets/images/banner.jpg";
  static String icono = "assets/icons/icono.png";

  //routes pages
  static int homePageStudent = 1;
}
