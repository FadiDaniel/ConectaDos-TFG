import 'package:conectados/model/experience.dart';

class Student {
  String? id;
  String? name;
  String? surnames;
  String? fp;
  String? city;
  String? highSchool;
  String? presentation;
  List<String>? interests;
  List<Experience>? experience;
  List<String>? skills;
  List<String>? likes;
  List<String>? dislikes;
  String? tutorPass;

  Student({
    required this.name,
    required this.surnames,
    required this.fp,
    required this.city,
    required this.highSchool,
    required this.presentation,
    required this.interests,
    required this.experience,
    required this.skills,
  });

  Student.all({
    required this.id,
    required this.name,
    required this.surnames,
    required this.fp,
    required this.city,
    required this.highSchool,
    required this.presentation,
    required this.interests,
    required this.experience,
    required this.skills,
    required this.likes,
    required this.dislikes,
  });

  Student.signUp({
    required this.name,
    required this.surnames,
    required this.fp,
    required this.city,
    required this.highSchool,
  });

  Student.updateCV({
    required this.presentation,
    required this.interests,
    required this.experience,
    required this.skills,
  });

  Student.like({
    required this.likes,
  });

  Student.dislike({
    required this.dislikes,
  });
}
