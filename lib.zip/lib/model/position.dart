class Position {
  String id;
  String name;
  List<String> fp;
  String city;
  String description;
  List<String> requirements;
  int vacants;

  Position(
      {required this.id,
      required this.name,
      required this.fp,
      required this.city,
      required this.description,
      required this.requirements,
      required this.vacants});
}
