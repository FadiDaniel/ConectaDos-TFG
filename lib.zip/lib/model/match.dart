class Match {
  String id;
  String idPosition;
  String idStudent;

  Match({required this.id, required this.idPosition, required this.idStudent});
}
