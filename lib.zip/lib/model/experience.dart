class Experience {
  String title;
  String position;

  Experience({
    required this.title,
    required this.position,
  });
}
