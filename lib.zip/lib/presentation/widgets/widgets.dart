import 'package:conectados/common/routes.dart';
import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/controller/functions.dart';
import 'package:conectados/presentation/screens/signup_login/login.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class Ws {
  static Widget cambiarIdioma(
      BuildContext context, Function cambiarIdioma, double altura) {
    return SizedBox(
      height: 52,
      width: 52,
      child: TextButton(
        onPressed: () {
          int i = -1;
          showMenu(
              color: Colors.white,
              position: RelativeRect.fromLTRB(0, 0, 0, 0),
              context: context,
              items: Ss.idiomas.map((String siglas) {
                i++;
                return PopupMenuItem(
                    child: GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: () {
                    cambiarIdioma(siglas);
                    Navigator.of(context).pop();
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          height: 30,
                          width: 30,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.grey.shade300),
                          child: Center(
                            child: Text(
                              siglas,
                              style: TextStyle(
                                  color: CStyles.primaryColor, fontSize: 14),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        Ss.idiomas2[i],
                        style: TextStyle(
                            color: CStyles.primaryColor, fontSize: 18),
                      )
                    ],
                  ),
                ));
              }).toList());
        },
        style: TextButton.styleFrom(
            shape: CircleBorder(), backgroundColor: Colors.grey.shade300),
        child: Text(Ss.idiomas[0],
            style: TextStyle(
                color: CStyles.primaryColor,
                fontWeight: FontWeight.bold,
                fontSize: 18)),
      ),
    );
  }

  //TextFields
  static TextField textFieldCheck(TextEditingController controller,
      String label, bool check, Function callbackTextfield, int index) {
    return TextField(
      controller: controller,
      decoration: WStyles.textInputCheck(check, label),
      onChanged: (value) {
        if (value.isNotEmpty) {
          callbackTextfield(true, index);
        }
      },
    );
  }

  static TextField textFieldPresentation(
      TextEditingController controlador, String label) {
    return TextField(
      maxLength: 500,
      maxLines: 6,
      controller: controlador,
      decoration: WStyles.textInputBig(label),
    );
  }

  static TextField textFieldBig(
      TextEditingController controller, String label) {
    return TextField(
      maxLines: 3,
      controller: controller,
      decoration: WStyles.textInputBig(label),
    );
  }

  static TextField textFieldBigCheck(TextEditingController controller,
      String label, bool check, Function callbackTextfield, int index) {
    return TextField(
      maxLines: 4,
      controller: controller,
      decoration: WStyles.textInputCheck(check, label),
      onChanged: (value) {
        if (value.isNotEmpty) {
          callbackTextfield(true, index);
        }
      },
    );
  }

  static TextField textField(TextEditingController controlador, String label) {
    return TextField(
      controller: controlador,
      decoration: WStyles.textInput(label),
    );
  }

  static TextField textFieldSkill(
      TextEditingController controlador, String label) {
    return TextField(
      controller: controlador,
      maxLines: 2,
      minLines: 2,
      decoration: WStyles.textInput(label),
    );
  }

  static TextField textFieldContrs(
      TextEditingController controlador,
      bool comprobador,
      String label,
      Function callbackTextfield,
      int tipo,
      bool obscure,
      Function callbackObscure) {
    return TextField(
      controller: controlador,
      obscureText: obscure,
      cursorColor: CStyles.primaryColor,
      decoration: WStyles.textInputCheck(comprobador, label).copyWith(
        suffixIcon: GestureDetector(
          child: obscure ? Icon(Icons.visibility) : Icon(Icons.visibility_off),
          onTap: () {
            callbackObscure(!obscure);
          },
        ),
      ),
      onChanged: (value) {
        if (value.isNotEmpty) {
          callbackTextfield(true, tipo);
        }
      },
    );
  }

  static TextField textFieldContrs2(
      TextEditingController controlador,
      bool comprobador,
      Function callbackTextfield,
      int tipo,
      bool obscure,
      Function callbackObscure) {
    return TextField(
      controller: controlador,
      obscureText: obscure,
      cursorColor: CStyles.primaryColor,
      decoration: WStyles.textInputCheck(comprobador, "").copyWith(
        suffixIcon: GestureDetector(
          child: obscure ? Icon(Icons.visibility) : Icon(Icons.visibility_off),
          onTap: () {
            callbackObscure(!obscure);
          },
        ),
      ),
      onChanged: (value) {
        if (value.isNotEmpty) {
          callbackTextfield(true, tipo);
        }
      },
    );
  }

  static RichText mandatoryText(String title, bool checker) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(text: title, style: TStyles.errorText(checker)),
          TextSpan(
              text: "*", style: TextStyle(color: Colors.red, fontSize: 16)),
        ],
      ),
    );
  }

  //select ExpansionTile
  static ExpansionTile searcherTile(
      ExpansionTileController controller,
      String title,
      String checker,
      bool boolean,
      List<String> original,
      List<String> filtered,
      Function callbackFiltered,
      Function callbackSelect) {
    return ExpansionTile(
      controller: controller,
      backgroundColor: Colors.white,
      title: Text(
        title,
        style: TextStyle(color: title == checker ? Colors.grey : Colors.black),
      ),
      collapsedShape: RoundedRectangleBorder(
          side: BorderSide(
              style: BorderStyle.solid,
              width: 1,
              color: boolean ? Colors.black54 : Colors.red.shade200),
          borderRadius: BorderRadius.circular(10)),
      shape: RoundedRectangleBorder(
          side: BorderSide(
              style: BorderStyle.solid,
              width: 1,
              color: boolean ? Colors.black54 : Colors.red.shade200),
          borderRadius: BorderRadius.circular(10)),
      initiallyExpanded: false,
      children: [
        Column(
          children: [
            //searcher
            SearchBar(
              hintStyle: WidgetStatePropertyAll(TextStyle(color: Colors.grey)),
              hintText: Ss.type,
              backgroundColor: WidgetStatePropertyAll(Colors.white),
              shadowColor: WidgetStatePropertyAll(Colors.transparent),
              shape: WidgetStatePropertyAll(RoundedRectangleBorder(
                  side: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(10))),
              onChanged: (value) {
                filtered = callbackFiltered(value);
              },
            ),
            //search results
            Builder(builder: (context) {
              if (filtered.length > 3) {
                return SizedBox(
                  height: 200,
                  child: SingleChildScrollView(
                    child: Ws.filteredList(filtered, callbackSelect),
                  ),
                );
              } else {
                return Ws.filteredList(filtered, callbackSelect);
              }
            })
          ],
        ),
      ],
    );
  }

  static ExpansionTile searcherTileAdd(
      ExpansionTileController controller,
      String title,
      bool boolean,
      List<String> original,
      List<String> filtered,
      Function callbackFiltered,
      Function callbackSelect) {
    return ExpansionTile(
      controller: controller,
      backgroundColor: Colors.white,
      title: Text(
        title,
        style: TextStyle(color: Colors.black),
      ),
      collapsedShape: RoundedRectangleBorder(
          side: BorderSide(
              style: BorderStyle.solid,
              width: 1,
              color: boolean ? Colors.black54 : Colors.red.shade200),
          borderRadius: BorderRadius.circular(10)),
      shape: RoundedRectangleBorder(
          side: BorderSide(
              style: BorderStyle.solid,
              width: 1,
              color: boolean ? Colors.black54 : Colors.red.shade200),
          borderRadius: BorderRadius.circular(10)),
      initiallyExpanded: false,
      children: [
        Column(
          children: [
            //searcher
            SearchBar(
              hintStyle: WidgetStatePropertyAll(TextStyle(color: Colors.grey)),
              hintText: Ss.type,
              backgroundColor: WidgetStatePropertyAll(Colors.white),
              shadowColor: WidgetStatePropertyAll(Colors.transparent),
              shape: WidgetStatePropertyAll(RoundedRectangleBorder(
                  side: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(10))),
              onChanged: (value) {
                filtered = callbackFiltered(value);
              },
            ),
            //search results
            Builder(builder: (context) {
              if (filtered.length > 3) {
                return SizedBox(
                  height: 200,
                  child: SingleChildScrollView(
                    child: Ws.filteredList(filtered, callbackSelect),
                  ),
                );
              } else {
                return Ws.filteredList(filtered, callbackSelect);
              }
            })
          ],
        ),
      ],
    );
  }

  //select high school widget
  static ShrinkWrappingViewport filteredList(
      List<String> filtered, Function callback) {
    return ShrinkWrappingViewport(
      offset: ViewportOffset.zero(),
      slivers: [
        SliverList.builder(
          itemCount: filtered.isEmpty ? 1 : filtered.length,
          itemBuilder: (context, index) {
            if (filtered.isEmpty) {
              return ListTile(
                title: Center(
                  child: Text(
                    Ss.noResults,
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ),
              );
            } else {
              return ListTile(
                title: GestureDetector(
                  onTap: () {
                    callback(index);
                  },
                  child: Text(filtered[index]),
                ),
              );
            }
          },
        ),
      ],
    );
  }

  //Separators
  static SizedBox smallSeparation = SizedBox(
    height: 10,
  );
  static SizedBox separation = SizedBox(
    height: 20,
  );
  static SizedBox bigSeparation = SizedBox(
    height: 30,
  );

  static Row dividerText(String text) {
    return Row(
      children: [
        Ws.divider,
        Text(text, style: TStyles.normalBlack),
        Ws.divider,
      ],
    );
  }

  static Expanded divider = Expanded(
      child: Divider(
    indent: 5,
    endIndent: 5,
  ));

  //waiting screen

  static Scaffold waitingScreen = Scaffold(
    body: PopScope(
      canPop: false,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(Routes.logo),
          CircularProgressIndicator(
            color: CStyles.primaryColor,
          ),
          smallSeparation,
          Text(
            Ss.pleaseWait,
            style: TStyles.boldBlack,
          )
        ],
      ),
    ),
  );

  //AppBar
  static AppBar appBar(String title, BuildContext context, Widget back) {
    return AppBar(
      centerTitle: true,
      shadowColor: Colors.black,
      backgroundColor: Colors.white,
      elevation: 3,
      scrolledUnderElevation: 2,
      surfaceTintColor: Colors.white,
      toolbarHeight: 90,
      leading: GestureDetector(
        onTap: () {
          Functions.navigateReplacement(back, context);
        },
        child: Ws.atrasAppBar(context),
      ),
      title: Padding(
        padding: EdgeInsets.only(bottom: 18, top: 18),
        child: Text(
          title,
          style: TStyles.appBarTitle,
        ),
      ),
    );
  }

  static AppBar appBarNoBack(String title, BuildContext context) {
    return AppBar(
      centerTitle: true,
      shadowColor: Colors.black,
      backgroundColor: Colors.white,
      elevation: 3,
      scrolledUnderElevation: 2,
      surfaceTintColor: Colors.white,
      toolbarHeight: 90,
      leading: SizedBox(),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 18, top: 18),
            child: Text(
              title,
              style: TStyles.appBarTitle,
            ),
          ),
        ],
      ),
    );
  }

  static AppBar appBarHomepage(BuildContext context) {
    return AppBar(
      centerTitle: true,
      shadowColor: Colors.black,
      backgroundColor: Colors.white,
      elevation: 3,
      scrolledUnderElevation: 2,
      surfaceTintColor: Colors.white,
      toolbarHeight: 90,
      leading: Builder(builder: (context) {
        return GestureDetector(
          onTap: () {
            Scaffold.of(context).openDrawer();
          },
          child: Container(
            margin: EdgeInsets.only(left: 10),
            child: Icon(
              Icons.menu,
              color: CStyles.primaryColor,
              size: 28,
            ),
          ),
        );
      }),
      title: Text(
        Ss.conectados,
        style: TStyles.appBarTitle,
      ),
      actions: [
        GestureDetector(
          onTap: () async {
            await Ws.popUpConfirm(Ss.signOut, Ss.messageSignOut, context,
                Ss.confirm, Ss.cancel, SG.auth.signOut);
            if (context.mounted && SG.auth.currentUser == null) {
              Functions.navigateReplacement(Login(), context);
            }
          },
          child: Container(
              height: 40,
              width: 40,
              margin: EdgeInsets.only(right: 15),
              child: Icon(
                Icons.logout_rounded,
                size: 30,
                color: CStyles.primaryColor,
              )),
        )
      ],
    );
  }

  //Iconos
  static Icon atrasAppBar(BuildContext context) {
    return Icon(
      Icons.arrow_back_ios_new_rounded,
      color: CStyles.primaryColor,
      size: 24,
    );
  }

  //Error messages
  static ScaffoldFeatureController<SnackBar, SnackBarClosedReason> errorMessage(
      String mensaje, BuildContext context) {
    return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        mensaje,
        style: TextStyle(fontSize: 20),
      ),
      duration: Duration(seconds: 2),
    ));
  }

  static Future<dynamic> popUpReturn(String titulo, String contenido,
      String volverA, BuildContext context, Widget clase) {
    if (contenido.isEmpty) {
      return showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(
            titulo,
            style: TStyles.boldBlack,
          ),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => clase));
                },
                child: Text(
                  volverA,
                  style: TStyles.normalBlack,
                )),
          ],
        ),
      );
    }
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          titulo,
          style: TStyles.boldBlack,
        ),
        content: Text(
          contenido,
          style: TStyles.normalBlack,
        ),
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => clase));
              },
              child: Text(
                volverA,
                style: TStyles.normalBlack,
              )),
        ],
      ),
    );
  }

  static Future<dynamic> popUpRemove(String titulo, String contenido,
      List<String> jobTitles, BuildContext context, Function remove) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          titulo,
          style: TStyles.boldBlack,
        ),
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                Ss.cancel,
                style: TStyles.normalBlack,
              )),
        ],
        content: SizedBox(
          height: MediaQuery.of(context).size.height / 3,
          width: MediaQuery.of(context).size.width,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text(contenido),
                ShrinkWrappingViewport(
                  offset: ViewportOffset.zero(),
                  slivers: [
                    SliverList.builder(
                      itemCount: jobTitles.length,
                      itemBuilder: (context, index) {
                        return Row(
                          children: [
                            Text(jobTitles[index]),
                            IconButton(
                                onPressed: () {
                                  remove(index);
                                  Navigator.of(context).pop();
                                },
                                icon: Icon(Icons.delete_forever))
                          ],
                        );
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static Future<dynamic> popUpConfirm(
    String title,
    String content,
    BuildContext context,
    String confirmMessage,
    String cancelMessage,
    Function confirm,
  ) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          title,
          style: TStyles.boldBlack,
        ),
        actions: [
          ElevatedButton(
            style: ButtonStyle(
                backgroundColor: WidgetStatePropertyAll(CStyles.backgroundPC),
                padding: WidgetStatePropertyAll(EdgeInsets.all(20))),
            onPressed: () async {
              await confirm();
              if (context.mounted) {
                Navigator.of(context).pop();
              }
            },
            child: Text(
              confirmMessage,
              style: TStyles.normalBlack,
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text(
              Ss.cancel,
              style: TStyles.normalBlack,
            ),
          ),
        ],
        content: Text(
          content,
          style: TStyles.normalBlack,
        ),
      ),
    );
  }

  //row add remove
  static Row rowAddRemove(String addText, String removeText,
      Function addFunction, Function removeFunction) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton(
          style: WStyles.addEB,
          onPressed: () {
            addFunction();
          },
          child: Text(
            addText,
            style: TStyles.smallBlack,
          ),
        ),
        SizedBox(
          width: 10,
        ),
        ElevatedButton(
          style: WStyles.removeEB,
          onPressed: () {
            removeFunction();
          },
          child: Text(
            removeText,
            style: TStyles.smallBlack,
          ),
        )
      ],
    );
  }
}
