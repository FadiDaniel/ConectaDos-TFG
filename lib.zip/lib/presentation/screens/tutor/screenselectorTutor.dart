import 'dart:convert';

import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:dartz/dartz.dart' hide State;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class HomepageTutor extends StatefulWidget {
  const HomepageTutor({super.key});

  @override
  State<HomepageTutor> createState() => _HomepageTutorState();
}

class _HomepageTutorState extends State<HomepageTutor> {
  bool seeStudents = true;
  bool seePositions = false;

  final codeController = TextEditingController();
  bool bCode = true;

  void callbackTextfield(bool check, int index) {
    setState(() {
      bCode = check;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Ws.appBarHomepage(context),
      drawer: Drawer(
        backgroundColor: CStyles.backgroundGrey,
        child: Column(
          //editar perfil tutor, eliminar alumnos
          children: [Text("s")],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            children: [
              Text(Ss.chooseUser),
              Row(
                children: [
                  ElevatedButton(
                      onPressed: () {
                        setState(() {
                          seeStudents = true;
                          seePositions = false;
                        });
                      },
                      child: Text(Ss.students)),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        seeStudents = false;
                        seePositions = true;
                      });
                    },
                    child: Text(Ss.position),
                  )
                ],
              ),
              Builder(builder: (context) {
                if (seeStudents) {
                  return FutureBuilder(
                    future: SG.firestore.retrieveStudents(SG.tutor!.code!),
                    builder: (context, snapshot) {
                      if (snapshot.data!.isEmpty) {
                        return Text("Hay 0 estudiantes");
                      } else {
                        return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            return Text("Alumno" + index.toString());
                          },
                        );
                      }
                    },
                  );
                } else {
                  return Text("no");
                }
                //to see students
                //   return FutureBuilder(
                //       future: SG.firestore
                //           .retrievePositions(SG.tutor!.city!, SG.tutor!.fp!),
                //       builder: (context, snapshot) {
                //         if (snapshot.connectionState ==
                //             ConnectionState.done) {
                //           snapshot.data!.fold((l) {
                //             return SizedBox();
                //           }, (r) {
                //             return ShrinkWrappingViewport(
                //               offset: ViewportOffset.zero(),
                //               slivers: [
                //                 SliverList.builder(
                //                   itemCount: r.length,
                //                   itemBuilder: (context, index) {
                //                     return SizedBox();
                //                   },
                //                 )
                //               ],
                //             );
                //           });
                //         } else {
                //           return Ws.waitingScreen;
                //         }
                //         return SizedBox();
                //       });
                // } else {
                //   return SizedBox();
                //   //to see positions
                //   // return FutureBuilder(
                //   //     future: SG.firestore.retrievePositions(
                //   //         SG.tutor!.fp!, SG.tutor!.city!),
                //   //     builder: (context, snapshot) {
                //   //       return ShrinkWrappingViewport(
                //   //         offset: ViewportOffset.zero(),
                //   //         slivers: [
                //   //           SliverList.builder(
                //   //             itemCount: ,
                //   //             itemBuilder: (context, index) {},
                //   //           )
                //   //         ],
                //   //       );
                //   //     });
                // }
              })
            ],
          ),
        ),
      ),
    );
  }
}
