import 'package:conectados/common/strings.dart';
import 'package:flutter/material.dart';

class DefaultBodyCompany extends StatefulWidget {
  const DefaultBodyCompany({super.key});

  @override
  State<DefaultBodyCompany> createState() => _DefaultBodyCompanyState();
}

class _DefaultBodyCompanyState extends State<DefaultBodyCompany> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Padding(
      padding: EdgeInsets.all(30),
      child: Column(
        children: [
          Row(
            children: [Text(Ss.student)],
          )
        ],
      ),
    ));
  }
}
