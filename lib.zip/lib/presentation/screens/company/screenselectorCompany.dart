import 'package:conectados/common/singleton.dart';
import 'package:conectados/presentation/screens/company/company_signup.dart';
import 'package:conectados/presentation/screens/company/homepage_company.dart';
import 'package:conectados/presentation/screens/company/positionEditor.dart';
import 'package:conectados/presentation/screens/company/positionListScreen.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ScreenSelectorCompany extends StatefulWidget {
  const ScreenSelectorCompany({super.key});

  @override
  State<ScreenSelectorCompany> createState() => _ScreenSelectorCompanyState();
}

class _ScreenSelectorCompanyState extends State<ScreenSelectorCompany> {
  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        return FutureBuilder(
          future: SG.firestore.isCompanySignUpDone(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              if (snapshot.data!) {
                return HomePageCompany(window: 0);
              } else {
                return CompanySignup();
              }
            } else {
              return Scaffold(
                body: Column(
                  children: [
                    CircularProgressIndicator(),
                    Center(
                        child: Text(
                      "Por favor espere",
                      style: TStyles.appBarTitle,
                    )),
                  ],
                ),
              );
            }
          },
        );
      },
    );
  }
}
