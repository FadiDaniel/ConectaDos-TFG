import 'package:conectados/common/strings.dart';
import 'package:conectados/model/position.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

List<Position> positions = [
  Position(
    id: "",
    name: "Informático",
    fp: ["DAM", "DAW"],
    city: "Madrid",
    description: "Hacer cosas de informático y sacarse el código de chapgtp",
    requirements: ["Saber estar", "Ducharse"],
    vacants: 1,
  )
];

class PositionListScreen extends StatefulWidget {
  const PositionListScreen({super.key, required this.callbackScreenSelector});
  final Function callbackScreenSelector;

  @override
  State<PositionListScreen> createState() => _PositionListScreenState();
}

class _PositionListScreenState extends State<PositionListScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Ws.appBar(
          Ss.titlePosition, context, widget.callbackScreenSelector(0)),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            children: [
              SizedBox(
                height: MediaQuery.sizeOf(context).height,
                child: Builder(builder: (context) {
                  if (positions.isEmpty) {
                    return Text("Holaaa");
                  } else {
                    return ListView.builder(
                      itemCount: positions.length,
                      itemBuilder: (context, index) {
                        return ElevatedButton(
                          style: WStyles.softEB,
                          onPressed: () {},
                          child: Padding(
                            padding: const EdgeInsets.only(top: 15, bottom: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  child: Text(
                                    "${Ss.position} ${index + 1}",
                                    style: TStyles.appBarTitle,
                                  ),
                                ),
                                Text(
                                  positions[index].name,
                                  style: TStyles.boldBlack,
                                ),
                                Text(
                                  positions[index].description,
                                  textAlign: TextAlign.justify,
                                  style: TStyles.normalBlack,
                                ),
                                Ws.smallSeparation,
                                Center(
                                  child: Text(
                                    "${Ss.aimFPs} ${positions[index].fp}",
                                    style: TStyles.normalBlack,
                                  ),
                                ),
                                Ws.smallSeparation,
                                Text(
                                  Ss.requeriments,
                                  textAlign: TextAlign.left,
                                  style: TStyles.boldBlack,
                                ),
                                ShrinkWrappingViewport(
                                  offset: ViewportOffset.zero(),
                                  slivers: [
                                    SliverList.builder(
                                      itemCount:
                                          positions[index].requirements.length,
                                      itemBuilder: (context, index2) {
                                        return Text(
                                          " - ${positions[index].requirements[index2]}",
                                          style: TStyles.normalBlack,
                                        );
                                      },
                                    )
                                  ],
                                ),
                                Ws.smallSeparation,
                                // Builder(
                                //   builder: (context) {
                                //     if (positions[index].valuable.isNotEmpty) {
                                //       return Column(
                                //         crossAxisAlignment:
                                //             CrossAxisAlignment.start,
                                //         children: [
                                //           Text(
                                //             Str.valuable,
                                //             textAlign: TextAlign.left,
                                //             style: TStyles.boldBlack,
                                //           ),
                                //           ShrinkWrappingViewport(
                                //             offset: ViewportOffset.zero(),
                                //             slivers: [
                                //               SliverList.builder(
                                //                 itemCount: positions[index]
                                //                     .valuable
                                //                     .length,
                                //                 itemBuilder: (context, index2) {
                                //                   return Text(
                                //                     " - ${positions[index].valuable[index2]}",
                                //                     style: TStyles.normalBlack,
                                //                   );
                                //                 },
                                //               )
                                //             ],
                                //           ),
                                //         ],
                                //       );
                                //     } else {
                                //       return SizedBox();
                                //     }
                                //   },
                                // )
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  }
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
