import 'package:conectados/presentation/screens/company/company_signup.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';

class HomePageCompany extends StatefulWidget {
  const HomePageCompany({super.key, required this.window});
  final int window;

  @override
  State<HomePageCompany> createState() => _HomePageCompanyState();
}

class _HomePageCompanyState extends State<HomePageCompany> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: Ws.appBarHomepage(context, CompanySignup(), Drawer()),
      body: PageView.builder(
        itemBuilder: (context, index) {
          switch (widget.window) {
            case 0:
              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(30),
                  child: Column(
                    children: [
                      Text("Homepage company"),
                    ],
                  ),
                ),
              );
            default:
              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(30),
                  child: Column(
                    children: [
                      Text("Homepage company"),
                    ],
                  ),
                ),
              );
          }
        },
      ),
    );
  }
}
