import 'package:conectados/common/strings.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class PositionEditor extends StatefulWidget {
  const PositionEditor({super.key, required this.callbackScreenSelector});
  final Function callbackScreenSelector;

  @override
  State<PositionEditor> createState() => _PositionEditorState();
}

class _PositionEditorState extends State<PositionEditor> {
  var title = TextEditingController();
  bool bTitle = true;
  var description = TextEditingController();
  bool bDescription = true;
  List<String> fps = [];
  bool bFPs = true;
  List<String> filteredFPs = Ss.fps;
  String correctedFP = "";
  var controllerTile = ExpansionTileController();

  List<TextEditingController> requirements = [TextEditingController()];
  bool bRequirements = true;

  void callbackTextfield(bool check, int index) {
    switch (index) {
      case 1:
        setState(() {
          bTitle = check;
        });
      case 2:
        setState(() {
          bDescription = check;
        });
    }
  }

  List<String> callbackFPFiltered(String value) {
    if (value.isEmpty) {
      setState(() {
        filteredFPs = Ss.fps;
      });
    } else {
      setState(() {
        filteredFPs = [];
      });
    }
    for (var fp_ in Ss.fps) {
      correctedFP = fp_;
      correctedFP = correctedFP.replaceAll("á", "a");
      correctedFP = correctedFP.replaceAll("é", "e");
      correctedFP = correctedFP.replaceAll("í", "i");
      correctedFP = correctedFP.replaceAll("ó", "o");
      correctedFP = correctedFP.replaceAll("ú", "u");
      if (correctedFP.toLowerCase().contains(value.toLowerCase()) ||
          fp_.toLowerCase().contains(value.toLowerCase())) {
        if (!filteredFPs.contains(fp_)) {
          setState(() {
            filteredFPs.add(fp_);
          });
        }
      } else {
        setState(() {
          filteredFPs.remove(fp_);
        });
      }
    }
    return filteredFPs;
  }

  void callbackFPSelect(int index) {
    setState(() {
      if (!fps.contains(Ss.fps[index])) {
        fps.add(Ss.fps[index]);
        setState(() {
          bFPs = true;
        });
        controllerTile.collapse();
      } else {
        Ws.errorMessage(Ss.fpAlreadySet, context);
      }
    });
  }

  void addRequirement() {
    if (requirements[requirements.length - 1].text.isNotEmpty) {
      setState(() {
        requirements.add(TextEditingController());
      });
    } else {
      Ws.errorMessage(Ss.fillRequirement, context);
    }
  }

  void removeRequirementPU() {
    if (requirements.length > 1) {
      if (requirements.last.text.isNotEmpty) {
        List<String> listRequirements = [];
        for (int i = 0; i < requirements.length; i++) {
          if (requirements[i].text.isNotEmpty) {
            listRequirements.add(requirements[i].text);
          }
        }
        Ws.popUpRemove(Ss.removeRequirement, Ss.removeRequirementDesc,
            listRequirements, context, removeRequirement);
      } else {
        setState(() {
          requirements.removeLast();
        });
      }
    } else {
      requirements[0].clear();
    }
  }

  void removeRequirement(int index) {
    setState(() {
      requirements.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Ws.mandatoryText(Ss.positionTitle, bTitle),
            Ws.smallSeparation,
            Ws.textFieldCheck(title, "", bTitle, callbackTextfield, 1),
            Ws.separation,
            Ws.mandatoryText(Ss.positionDescription, bDescription),
            Ws.smallSeparation,
            Ws.textFieldBigCheck(
                description, "", bDescription, callbackTextfield, 2),
            Ws.separation,
            Ws.mandatoryText(Ss.aimFPs, bFPs),
            Ws.smallSeparation,
            Ws.searcherTileAdd(controllerTile, Ss.pressToShow, bFPs, Ss.fps,
                filteredFPs, callbackFPFiltered, callbackFPSelect),
            Builder(builder: (context) {
              if (fps.isEmpty) {
                return SizedBox();
              } else {
                return ShrinkWrappingViewport(
                  offset: ViewportOffset.zero(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: Ws.separation,
                    ),
                    SliverList.separated(
                      separatorBuilder: (context, index) {
                        return SizedBox(
                          height: 5,
                        );
                      },
                      itemCount: fps.length,
                      itemBuilder: (context, index) {
                        return Container(
                          padding: EdgeInsets.all(15),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.black54),
                              borderRadius: BorderRadius.circular(30)),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 6,
                                child: Text(
                                  textAlign: TextAlign.center,
                                  fps[index],
                                  style: TStyles.boldBlack,
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        fps.removeAt(index);
                                      });
                                    },
                                    icon: Icon(
                                      Icons.delete_forever,
                                      size: 30,
                                    )),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                );
              }
            }),
            Ws.separation,
            Row(
              children: [
                Ws.divider,
                Text(Ss.requeriments, style: TStyles.normalBlack),
                Ws.divider,
              ],
            ),
            Ws.smallSeparation,
            SizedBox(
              height: requirements.length.toDouble() * 60,
              width: double.infinity,
              child: ReorderableListView.builder(
                buildDefaultDragHandles: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return Column(
                    key: ValueKey(index),
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 5.0, bottom: 5),
                        height: 50,
                        width: MediaQuery.sizeOf(context).width - 60 - 50,
                        child: Ws.textFieldSkill(requirements[index],
                            "${Ss.requirement} ${index + 1}"),
                      ),
                    ],
                  );
                },
                itemCount: requirements.length,
                onReorder: (oldIndex, newIndex) {
                  if (requirements.last.text.isEmpty) {
                    Ws.errorMessage(Ss.fillLast, context);
                    return;
                  }
                  setState(() {
                    TextEditingController requirement =
                        requirements.removeAt(oldIndex);
                    if (newIndex > requirements.length) {
                      requirements.add(requirement);
                    } else {
                      requirements.insert(newIndex, requirement);
                    }
                  });
                },
              ),
            ),
            Ws.smallSeparation,
            Ws.rowAddRemove(Ss.addRequirement, Ss.remove, addRequirement,
                removeRequirementPU),
            Ws.bigSeparation,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  if (title.text.isEmpty ||
                      description.text.isEmpty ||
                      fps.isEmpty) {
                    Ws.errorMessage(Ss.fill, context);
                  }
                  setState(() {
                    if (title.text.isEmpty) {
                      bTitle = false;
                    }
                    if (description.text.isEmpty) {
                      bDescription = false;
                    }
                    if (fps.isEmpty) {
                      bFPs = false;
                    }
                  });
                  if (bTitle && bDescription && bFPs) {
                    Ws.popUpReturn(Ss.positionCreated, "", Ss.returnHomePage,
                        context, widget.callbackScreenSelector(0));
                  }
                },
                style: WStyles.elevatedButtonPC,
                child: Text(
                  Ss.makePosition,
                  style: TStyles.boldWhite,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
