import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/controller/functions.dart';
import 'package:conectados/model/experience.dart';
import 'package:conectados/model/student.dart';
import 'package:conectados/presentation/screens/student/homepage_student.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:dartz/dartz.dart' hide State;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class ModifyCV extends StatefulWidget {
  const ModifyCV({super.key});

  @override
  State<ModifyCV> createState() => _ModifyCVState();
}

class _ModifyCVState extends State<ModifyCV> {
  var presentation = TextEditingController();

  void addExperience() {
    if (jobTitles[jobTitles.length - 1].text.isNotEmpty &&
        jobDescriptions[jobDescriptions.length - 1].text.isNotEmpty) {
      setState(() {
        jobDescriptions.add(TextEditingController());
        jobTitles.add(TextEditingController());
      });
    } else {
      Ws.errorMessage(Ss.fillExp, context);
    }
  }

  void removeExperiencePU() {
    if (jobDescriptions.length > 1) {
      List<String> jobtitleslist = [];
      for (int i = 0; i < jobTitles.length; i++) {
        if (jobTitles[i].text.isNotEmpty) {
          jobtitleslist.add(jobTitles[i].text);
        }
      }
      Ws.popUpRemove(Ss.removeJob, Ss.removeJobDesc, jobtitleslist, context,
          removeExperience);
    } else {
      jobTitles[0].clear();
      jobDescriptions[0].clear();
    }
  }

  void removeExperience(int index) {
    setState(() {
      jobTitles.removeAt(index);
      jobDescriptions.removeAt(index);
    });
  }

  void addSkill() {
    if (skills[skills.length - 1].text.isNotEmpty) {
      setState(() {
        skills.add(TextEditingController());
      });
    } else {
      Ws.errorMessage(Ss.fillSkill, context);
    }
  }

  void removeSkillPU() {
    if (skills.length > 1) {
      if (skills[skills.length - 1].text.isNotEmpty) {
        List<String> listskills = [];
        for (int i = 0; i < skills.length; i++) {
          if (skills[i].text.isNotEmpty) {
            listskills.add(skills[i].text);
          }
        }
        Ws.popUpRemove(Ss.removeSkill, Ss.removeSkillDesc, listskills, context,
            removeSkill);
      } else {
        setState(() {
          skills.removeLast();
        });
      }
    } else {
      setState(() {
        skills[skills.length - 1].clear();
      });
    }
  }

  void removeSkill(int index) {
    setState(() {
      skills.removeAt(index);
    });
  }

  void addInterest() {
    if (interests[interests.length - 1].text.isNotEmpty) {
      setState(() {
        interests.add(TextEditingController());
      });
    } else {
      Ws.errorMessage(Ss.fillInterest, context);
    }
  }

  void removeInterestPU() {
    if (interests.length > 1) {
      if (interests.last.text.isNotEmpty) {
        List<String> listInterests = [];
        for (int i = 0; i < interests.length; i++) {
          if (interests[i].text.isNotEmpty) {
            listInterests.add(interests[i].text);
          }
        }
        Ws.popUpRemove(Ss.removeInterest, Ss.removeInterestDesc, listInterests,
            context, removeInterest);
      } else {
        setState(() {
          interests.removeLast();
        });
      }
    } else {
      interests[0].clear();
    }
  }

  void removeInterest(int index) {
    setState(() {
      interests.removeAt(index);
    });
  }

  List<TextEditingController> jobTitles = [TextEditingController()];
  List<TextEditingController> jobDescriptions = [TextEditingController()];
  List<TextEditingController> skills = [TextEditingController()];
  List<TextEditingController> interests = [TextEditingController()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Ws.appBar(Ss.modifyCV, context, HomepageStudent()),
      body: SafeArea(
        child: PopScope(
          canPop: true,
          onPopInvokedWithResult: (didPop, result) {
            Functions.navigateReplacement(HomepageStudent(), context);
          },
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(30.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //Job experience
                  Ws.dividerText(Ss.professionalExp),
                  Ws.separation,
                  //professional experiences
                  ShrinkWrappingViewport(
                      offset: ViewportOffset.zero(),
                      slivers: [
                        SliverList.builder(
                          itemCount: jobDescriptions.length,
                          itemBuilder: (context, index) {
                            return Column(
                              children: [
                                Ws.textField(jobTitles[index], Ss.jobTitle),
                                SizedBox(
                                  height: 10,
                                ),
                                Ws.textFieldBig(
                                    jobDescriptions[index], Ss.jobFunctions),
                                Ws.smallSeparation,
                              ],
                            );
                          },
                        )
                      ]),
                  Ws.smallSeparation,
                  Ws.rowAddRemove(
                      Ss.addExp, Ss.remove, addExperience, removeExperiencePU),
                  Ws.bigSeparation,
                  //skills
                  Ws.dividerText(Ss.skills),
                  Ws.separation,
                  SizedBox(
                    height: skills.length.toDouble() * 60,
                    width: double.infinity,
                    child: ReorderableListView.builder(
                      buildDefaultDragHandles: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Column(
                          key: ValueKey(index),
                          children: [
                            Container(
                              margin:
                                  const EdgeInsets.only(top: 5.0, bottom: 5),
                              height: 50,
                              width: MediaQuery.sizeOf(context).width - 60 - 50,
                              child: Ws.textFieldSkill(
                                  skills[index], "${Ss.skill} ${index + 1}"),
                            ),
                          ],
                        );
                      },
                      itemCount: skills.length,
                      onReorder: (oldIndex, newIndex) {
                        if (skills.last.text.isEmpty) {
                          Ws.errorMessage(Ss.fillLast, context);
                          return;
                        }
                        setState(() {
                          TextEditingController skill =
                              skills.removeAt(oldIndex);
                          if (newIndex > skills.length) {
                            skills.add(skill);
                          } else {
                            skills.insert(newIndex, skill);
                          }
                        });
                      },
                    ),
                  ),
                  Ws.smallSeparation,
                  Ws.rowAddRemove(
                      Ss.addSkill, Ss.remove, addSkill, removeSkillPU),
                  Ws.bigSeparation,
                  //interests
                  Ws.dividerText(Ss.interests),
                  Ws.smallSeparation,
                  SizedBox(
                    height: interests.length.toDouble() * 60,
                    width: double.infinity,
                    child: ReorderableListView.builder(
                      buildDefaultDragHandles: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Column(
                          key: ValueKey(index),
                          children: [
                            Container(
                              margin:
                                  const EdgeInsets.only(top: 5.0, bottom: 5),
                              height: 50,
                              width: MediaQuery.sizeOf(context).width - 60 - 50,
                              child: Ws.textFieldSkill(interests[index],
                                  "${Ss.interest} ${index + 1}"),
                            ),
                          ],
                        );
                      },
                      itemCount: interests.length,
                      onReorder: (oldIndex, newIndex) {
                        if (interests.last.text.isEmpty) {
                          Ws.errorMessage(Ss.fillLast, context);
                          return;
                        }
                        setState(() {
                          TextEditingController interest =
                              interests.removeAt(oldIndex);
                          if (newIndex > interests.length) {
                            interests.add(interest);
                          } else {
                            interests.insert(newIndex, interest);
                          }
                        });
                      },
                    ),
                  ),
                  Ws.smallSeparation,
                  Ws.rowAddRemove(
                      Ss.addInterest, Ss.remove, addInterest, removeInterestPU),
                  //presentation letter
                  Ws.bigSeparation,
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                            text: Ss.presentation, style: TStyles.normalBlack),
                        TextSpan(
                            text: Ss.charactersMax,
                            style: TStyles.normalBlack.copyWith(fontSize: 14)),
                      ],
                    ),
                  ),
                  Ws.smallSeparation,
                  Ws.textFieldPresentation(presentation, ""),
                  Ws.separation,
                  //finish button
                  Center(
                    child: SizedBox(
                      width: MediaQuery.sizeOf(context).width,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: () async {
                          //controlls of fieltexts name and surname
                          //controllers of fp, city and highschool

                          //everything fine

                          if (skills.last.text.isEmpty) {
                            skills.removeLast();
                          }
                          if (jobTitles.last.text.isEmpty ||
                              jobDescriptions.last.text.isEmpty) {
                            jobTitles.removeLast();
                            jobDescriptions.removeLast();
                          }
                          if (interests.last.text.isEmpty) {
                            interests.removeLast();
                          }
                          List<Experience> experiences = [];
                          for (int i = 0; i < jobTitles.length; i++) {
                            experiences.add(Experience(
                                title: jobTitles[i].text,
                                position: jobDescriptions[i].text));
                          }
                          Student student = Student.updateCV(
                            presentation: presentation.text,
                            interests: interests.map(
                              (TextEditingController e) {
                                return e.text;
                              },
                            ).toList(),
                            experience: experiences,
                            skills: skills.map(
                              (TextEditingController e) {
                                return e.text;
                              },
                            ).toList(),
                          );

                          bool either =
                              await SG.firestore.writeStudent(student);
                          if (either) {
                            Functions.navigateReplacement(
                                HomepageStudent(), context);
                          } else {
                            Ws.errorMessage(Ss.errorWriteDB, context);
                          }
                        },
                        style: WStyles.elevatedButtonPC,
                        child: Text(
                          Ss.finalize,
                          style: TStyles.boldWhite,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
