import 'package:conectados/common/singleton.dart';
import 'package:conectados/presentation/screens/company/company_signup.dart';
import 'package:conectados/presentation/screens/company/homepage_company.dart';
import 'package:conectados/presentation/screens/company/positionEditor.dart';
import 'package:conectados/presentation/screens/company/positionListScreen.dart';
import 'package:conectados/presentation/screens/student/homepage_student.dart';
import 'package:conectados/presentation/screens/student/student_signup.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:flutter/cupertino.dart';

class ScreenSelectorStudent extends StatefulWidget {
  const ScreenSelectorStudent({super.key});

  @override
  State<ScreenSelectorStudent> createState() => _ScreenSelectorStudentState();
}

class _ScreenSelectorStudentState extends State<ScreenSelectorStudent> {
  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        return FutureBuilder(
          future: SG.firestore.isStudentSignUpDone(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              if (snapshot.data!) {
                return HomepageStudent();
              } else {
                return StudentSignup();
              }
            } else {
              return Ws.waitingScreen;
            }
          },
        );
      },
    );
  }
}
