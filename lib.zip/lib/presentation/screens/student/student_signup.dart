import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/controller/functions.dart';
import 'package:conectados/model/experience.dart';
import 'package:conectados/model/student.dart';
import 'package:conectados/presentation/screens/signup_login/signUpType.dart';
import 'package:conectados/presentation/screens/student/homepage_student.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:dartz/dartz.dart' hide State;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class StudentSignup extends StatefulWidget {
  const StudentSignup({
    super.key,
  });
  @override
  State<StudentSignup> createState() => _StudentSignupState();
}

class _StudentSignupState extends State<StudentSignup> {
  bool bName = true;
  bool bSurnames = true;
  TextEditingController name = TextEditingController();
  TextEditingController surnames = TextEditingController();

  bool bFP = true;
  var contrFP = ExpansionTileController();
  String fp = Ss.selectFP;
  List<String> filteredFP = Ss.fps;
  String correctedFP = "";

  bool bCity = true;
  var contrCity = ExpansionTileController();
  String city = Ss.selectCity;
  List<String> filteredCities = Ss.cities;
  String correctedCity = "";

  bool bHighSchool = true;
  var contrHighSchool = ExpansionTileController();
  String highSchool = Ss.selectHighSchool;
  List<String> filteredHS = Ss.highSchools;
  String correctedHS = "";

  void callbackTF(bool check) {
    setState(() {
      bCity = check;
    });
  }

  void callbackHS(int index) {
    setState(() {
      highSchool = filteredHS[index];
      contrHighSchool.collapse();
      filteredHS = Ss.highSchools;
      bHighSchool = true;
    });
  }

  List<String> callbackHSFiltered(String value) {
    if (value.isEmpty) {
      setState(() {
        filteredHS = Ss.highSchools;
      });
    } else {
      setState(() {
        filteredHS = [];
      });
    }
    for (var highSchool_ in Ss.highSchools) {
      correctedHS = highSchool_;
      correctedHS = correctedHS.replaceAll("á", "a");
      correctedHS = correctedHS.replaceAll("é", "e");
      correctedHS = correctedHS.replaceAll("í", "i");
      correctedHS = correctedHS.replaceAll("ó", "o");
      correctedHS = correctedHS.replaceAll("ú", "u");
      if (correctedHS.toLowerCase().contains(value.toLowerCase()) ||
          highSchool_.toLowerCase().contains(value.toLowerCase())) {
        if (!filteredHS.contains(highSchool_)) {
          setState(() {
            filteredHS.add(highSchool_);
          });
        }
      } else {
        setState(() {
          filteredHS.remove(highSchool_);
        });
      }
    }
    return filteredHS;
  }

  void callbackCity(int index) {
    setState(() {
      city = filteredCities[index];
      contrCity.collapse();
      filteredCities = Ss.cities;
      bCity = true;
    });
  }

  List<String> callbackFPFiltered(String value) {
    if (value.isEmpty) {
      setState(() {
        filteredFP = Ss.fps;
      });
    } else {
      setState(() {
        filteredFP = [];
      });
    }
    for (var fp_ in Ss.fps) {
      correctedFP = fp_;
      correctedFP = correctedFP.replaceAll("á", "a");
      correctedFP = correctedFP.replaceAll("é", "e");
      correctedFP = correctedFP.replaceAll("í", "i");
      correctedFP = correctedFP.replaceAll("ó", "o");
      correctedFP = correctedFP.replaceAll("ú", "u");
      if (correctedFP.toLowerCase().contains(value.toLowerCase()) ||
          fp_.toLowerCase().contains(value.toLowerCase())) {
        if (!filteredFP.contains(fp_)) {
          setState(() {
            filteredFP.add(fp_);
          });
        }
      } else {
        setState(() {
          filteredFP.remove(fp_);
        });
      }
    }
    return filteredFP;
  }

  void callbackFP(int index) {
    setState(() {
      fp = filteredFP[index];
      contrFP.collapse();
      filteredFP = Ss.fps;
      bFP = true;
    });
  }

  List<String> callbackCityFiltered(String value) {
    if (value.isEmpty) {
      setState(() {
        filteredCities = Ss.cities;
      });
    } else {
      setState(() {
        filteredCities = [];
      });
    }
    for (var city_ in Ss.cities) {
      correctedCity = city_;
      correctedCity = correctedCity.replaceAll("á", "a");
      correctedCity = correctedCity.replaceAll("é", "e");
      correctedCity = correctedCity.replaceAll("í", "i");
      correctedCity = correctedCity.replaceAll("ó", "o");
      correctedCity = correctedCity.replaceAll("ú", "u");
      if (correctedCity.toLowerCase().contains(value.toLowerCase()) ||
          city_.toLowerCase().contains(value.toLowerCase())) {
        if (!filteredCities.contains(city_)) {
          setState(() {
            filteredCities.add(city_);
          });
        }
      } else {
        setState(() {
          filteredCities.remove(city_);
        });
      }
    }
    return filteredCities;
  }

  void callbackTextfield(bool check, int index) {
    setState(() {
      switch (index) {
        case 1:
          bName = check;
          return;
        case 2:
          bSurnames = check;
          return;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Ws.appBarNoBack(Ss.studentSignUp, context),
      body: SafeArea(
        child: PopScope(
          canPop: true,
          onPopInvokedWithResult: (didPop, result) {
            Functions.navigateReplacement(Signuptype(), context);
          },
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(30.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Ws.mandatoryText(Ss.name, bName),
                  Ws.smallSeparation,
                  //name 1
                  Ws.textFieldCheck(name, "", bName, callbackTextfield, 1),
                  Ws.separation,
                  Ws.mandatoryText(Ss.surname, bSurnames),
                  Ws.smallSeparation,
                  //surnames 2
                  Ws.textFieldCheck(
                      surnames, "", bSurnames, callbackTextfield, 2),
                  Ws.separation,
                  //FP
                  Ws.mandatoryText(Ss.fp, bFP),
                  Ws.smallSeparation,
                  Ws.searcherTile(contrFP, fp, Ss.selectFP, bFP, Ss.fps,
                      filteredFP, callbackFPFiltered, callbackFP),
                  Ws.separation,
                  //City
                  Ws.mandatoryText(Ss.city, bCity),
                  Ws.smallSeparation,
                  Ws.searcherTile(
                      contrCity,
                      city,
                      Ss.selectCity,
                      bCity,
                      Ss.cities,
                      filteredCities,
                      callbackCityFiltered,
                      callbackCity),
                  Ws.separation,
                  //HighSchool
                  Ws.mandatoryText(Ss.highSchool, bHighSchool),
                  Ws.smallSeparation,
                  Ws.searcherTile(
                      contrHighSchool,
                      highSchool,
                      Ss.selectHighSchool,
                      bHighSchool,
                      Ss.highSchools,
                      filteredHS,
                      callbackHSFiltered,
                      callbackHS),
                  Ws.separation,
                  //Job experience
                  Ws.dividerText(Ss.professionalExp),
                  Ws.separation,
                  //finish button
                  Center(
                    child: SizedBox(
                      width: MediaQuery.sizeOf(context).width,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: () async {
                          //controlls of fieltexts name and surname
                          if (name.text.isEmpty || surnames.text.isEmpty) {
                            Ws.errorMessage(Ss.fill, context);
                          }
                          if (name.text.isEmpty) {
                            setState(() {
                              bName = false;
                            });
                          }
                          if (surnames.text.isEmpty) {
                            setState(() {
                              bSurnames = false;
                            });
                          }
                          //controllers of fp, city and highschool
                          if (fp == Ss.selectFP ||
                              city == Ss.selectCity ||
                              highSchool == Ss.selectHighSchool) {
                            Ws.errorMessage(Ss.fill, context);
                          }
                          if (fp == Ss.selectFP) {
                            setState(() {
                              bFP = false;
                            });
                          }
                          if (city == Ss.selectCity) {
                            setState(() {
                              bCity = false;
                            });
                          }
                          if (highSchool == Ss.selectHighSchool) {
                            setState(() {
                              bHighSchool = false;
                            });
                          }
                          //everything fine
                          if (bFP &&
                              bCity &&
                              bHighSchool &&
                              bName &&
                              bSurnames) {
                            Student student = Student.signUp(
                              name: name.text,
                              surnames: surnames.text,
                              fp: fp,
                              highSchool: highSchool,
                              city: city,
                            );
                            bool either =
                                await SG.firestore.writeStudent(student);
                            if (either) {
                              Functions.navigateReplacement(
                                  HomepageStudent(), context);
                            } else {
                              Ws.errorMessage(Ss.errorWriteDB, context);
                            }
                          }
                        },
                        style: WStyles.elevatedButtonPC,
                        child: Text(
                          Ss.finalize,
                          style: TStyles.boldWhite,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
