import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/controller/functions.dart';
import 'package:conectados/model/company.dart';
import 'package:conectados/model/position.dart';
import 'package:conectados/presentation/screens/signup_login/login.dart';
import 'package:conectados/presentation/screens/student/student_signup.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class HomepageStudent extends StatefulWidget {
  const HomepageStudent({super.key});

  @override
  State<HomepageStudent> createState() => _HomepageStudentState();
}

List<Position> positions = [
  Position(
    id: "",
    name: "Ayudante de Java",
    fp: ["DAM", "DAW"],
    city: "Madrid",
    description: "Desarrollar aplicaciones móviles",
    requirements: ["Conocimiento en Java", "Conocimiento en PHP"],
    vacants: 1,
  ),
  Position(
    id: "",
    name: "Desarrollador web junior",
    fp: ["DAM", "DAW"],
    city: "Madrid",
    description: "Desarrollar aplicaciones web",
    requirements: ["Conocimiento en JavaScript", "Conocimiento en HTML"],
    vacants: 1,
  )
];

class _HomepageStudentState extends State<HomepageStudent> {
  var pageController = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: Drawer(
          child: Text(SG.student!.city!),
        ),
        appBar: Ws.appBarHomepage(
          context,
        ),
        body: FutureBuilder(
          future: SG.firestore
              .retrievePositions(SG.student!.fp!, SG.student!.city!),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return ListView.builder(
                itemCount: snapshot.data!.length(),
                itemBuilder: (context, index) {
                  return ElevatedButton(
                    onPressed: () {},
                    child: Column(
                      children: [],
                    ),
                  );
                },
              );
            } else {
              return Ws.waitingScreen;
            }
          },
        ));
  }
}
