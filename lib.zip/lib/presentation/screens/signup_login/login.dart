import 'package:conectados/common/routes.dart';
import 'package:conectados/common/singleton.dart';
import 'package:conectados/common/strings.dart';
import 'package:conectados/controller/functions.dart';
import 'package:conectados/presentation/screens/company/homepage_company.dart';
import 'package:conectados/presentation/screens/company/screenselectorCompany.dart';
import 'package:conectados/presentation/screens/signup_login/resetPassword.dart';
import 'package:conectados/presentation/screens/signup_login/signUp.dart';
import 'package:conectados/presentation/screens/signup_login/signUpType.dart';
import 'package:conectados/presentation/screens/student/homepage_student.dart';
import 'package:conectados/presentation/screens/student/screenselectorStudent.dart';
import 'package:conectados/presentation/screens/tutor/screenselectorTutor.dart';
import 'package:conectados/presentation/themes/styles.dart';
import 'package:conectados/presentation/widgets/widgets.dart';
import 'package:dartz/dartz.dart' hide State;
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  void cambiarIdioma() {}

  void callbackTextfield(bool check, int index) {
    switch (index) {
      case 1:
        setState(() {
          bEmail = check;
          return;
        });
      case 2:
        setState(() {
          bPassword = check;
          return;
        });
    }
  }

  void callbackObscure(bool check) {
    setState(() {
      obscure = check;
    });
  }

  Future<void> sendEmail() async {
    await SG.auth.currentUser!.sendEmailVerification();
  }

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  bool bEmail = true;
  bool bPassword = true;
  bool obscure = true;

  @override
  Widget build(BuildContext context) {
    var keyboardHeight = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      appBar: AppBar(
        title: Text(Ss.login),
        leading: SizedBox(),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            padding: EdgeInsets.all(30),
            child: SizedBox(
              height: constraints.maxHeight - 60 + keyboardHeight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Center(
                    child: Image.asset(
                      Routes.logo,
                      width: 300,
                      height: 300,
                    ),
                  ),
                  Ws.textFieldCheck(
                      email, Ss.email, bEmail, callbackTextfield, 1),
                  Ws.textFieldContrs(password, bPassword, Ss.password,
                      callbackTextfield, 2, obscure, callbackObscure),
                  Center(
                    child: TextButton(
                        onPressed: () {
                          Functions.navigateReplacement(
                              ResetPassword(), context);
                        },
                        child: Text(
                          Ss.forgotten,
                          style: TStyles.boldBlack,
                        )),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (email.text.isEmpty) {
                          callbackTextfield(false, 1);
                        }
                        if (password.text.isEmpty) {
                          callbackTextfield(false, 2);
                        }
                        if (email.text.isEmpty || password.text.isEmpty) {
                          Ws.errorMessage(Ss.fill, context);
                          return;
                        }
                        if (!Functions.checkEmail(email.text)) {
                          callbackTextfield(false, 1);
                          Ws.errorMessage(Ss.errorEmail, context);
                          return;
                        }
                        if (bEmail && bPassword) {
                          if (await SG.auth.logIn(
                              email: email.text, password: password.text)) {
                            if (context.mounted &&
                                SG.auth.currentUser!.emailVerified) {
                              if (SG.student != null) {
                                Functions.navigateReplacement(
                                    ScreenSelectorStudent(), context);
                                return;
                              }
                              if (SG.tutor != null) {
                                Functions.navigateReplacement(
                                    HomepageTutor(), context);
                                return;
                              }
                              if (SG.company != null) {
                                Functions.navigateReplacement(
                                    ScreenSelectorCompany(), context);
                                return;
                              }
                              Functions.navigateReplacement(
                                  Signuptype(), context);
                            } else {
                              if (context.mounted) {
                                Ws.popUpConfirm(
                                    Ss.emailNotVerified,
                                    Ss.emailNotVerifiedContent,
                                    context,
                                    Ss.sendEmailAgain,
                                    Ss.cancel,
                                    sendEmail);
                              }
                            }
                          } else {
                            if (context.mounted) {
                              Ws.errorMessage(Ss.loginError, context);
                            }
                          }
                        }
                      },
                      style: WStyles.elevatedButtonPC,
                      child: Text(
                        Ss.enter,
                        style: TStyles.boldWhite,
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Divider(
                          height: 20,
                        ),
                      ),
                      Text(Ss.dontHave),
                      Expanded(child: Divider())
                    ],
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Functions.navigateReplacement(SignUp(), context);
                      },
                      style: WStyles.elevatedButtonPC,
                      child: Text(
                        Ss.makeAccount,
                        style: TStyles.boldWhite,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
